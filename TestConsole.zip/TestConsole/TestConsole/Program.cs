﻿class Test
{
    public static void Main()
    {
        try
        {
            using(StreamReader sr = new StreamReader("C:\\Users\\praja\\Desktop\\Azure\\data.csv"))
            {
                string currentLine;
                int currentIndex = 0;
                while ((currentLine = sr.ReadLine()) != null)
                {
                    if(currentIndex > 0)
                    {
                        Console.WriteLine(currentLine);
                        using(StreamReader reader = new StreamReader("C:\\Users\\praja\\Desktop\\Azure\\test.html"))
                        {
                            string line = reader.ReadToEnd();
                            var newText = currentLine.Split(',');
                            string replacedLine = line.Replace("#{replaceTitle}#", newText[0]).Replace("#{replaceBody}#", newText[1]);
                            File.WriteAllText($"C:\\Users\\praja\\Desktop\\Azure\\File{currentIndex - 1}.html", replacedLine);
                        }
                    }
                    currentIndex++;
                }
            }
        }
        catch(Exception ex)
        {
            Console.WriteLine(ex.Message + ex.InnerException);
        }
    }
}